(function($){
    $(document).ready(function() {
        alert('Congradulation you are now able to use custom script.')
    });
})(jQuery);
