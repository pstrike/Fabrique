<?php

class Fabrique_Image_Control extends WP_Customize_Image_Control
{
	public function __construct( $manager, $id, $args = array() )
	{
		$this->button_label = isset( $args['button_label'] ) ? $args['button_label'] : esc_html__( 'Choose', 'fabrique-core' );

		parent::__construct( $manager, $id, $args );

		$this->add_tab( 'library', esc_html__( 'Media Library', 'fabrique-core' ), array( $this, 'library_tab' ) );
	}

	protected function library_tab()
	{
		$output  = '';

		if ( !empty( $this->label ) )
			$output .= '<span class="customize-control-title">' . esc_html( $this->label ) . '</span>';

		$attributes = array();
		$attributes[] = 'class="js-media-library bp-input-group-button"';
		$attributes[] = 'data-controller="' . esc_attr( $this->id ) . '"';
		$attributes[] = 'data-type="' . esc_attr( $this->get_media_type() ) . '"';

		$output .= '<div class="js-customize-media bp-input-group">';
		$output .=   '<input type="text" class="js-media-input bp-input" value="' . esc_attr( $this->value() ) . '" />';
		$output .=   '<span ' . implode( ' ', $attributes ) . '">' . esc_html( $this->button_label ) . '</span>';
		$output .= '</div>';

		echo fabrique_core_escape_content( $output );
	}

	protected function get_media_type()
	{
		return 'image';
	}
}
