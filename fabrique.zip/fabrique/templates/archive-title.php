<?php
/**
 * The template file
 *
 * @package fabrique/templates
 * @version 1.0.0
 */
?>


<?php $opts = fabrique_archive_title_options(); ?>
<?php fabrique_template( 'page-title', $opts ); ?>
